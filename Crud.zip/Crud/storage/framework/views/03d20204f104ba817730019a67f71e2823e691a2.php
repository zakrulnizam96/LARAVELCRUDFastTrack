<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>   
    </head>
    <body>

        <div><button style="float: right" class="mb-4 mr-2 mt-3 btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button></div>

        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Product</th>
                <th scope="col">Description</th>
                <th scope="col">Seller</th>
                <th scope="col">Pic</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $product_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->desc); ?></td>
                <td> <?php echo e($product->seller); ?></td>
                <td><img style="width: 30%" src="images/<?php echo e($product->pic); ?>" alt="prodimg"></td>
                <td>
                <a class="btn btn-success" href="/edit/<?php echo e($product->id); ?>">Edit</a>
                    <a class="btn btn-danger" href="/delete/<?php echo e($product->id); ?>">Delete</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
          </table>

          <!-- The Modal -->

          <div class="modal" id="myModal">

            <div class="modal-dialog">

              <div class="modal-content">

              

                <!-- Modal Header -->

                <div class="modal-header">

                  <h4 class="modal-title">Create Product</h4>

                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>

                

                <!-- Modal body -->

                <div class="modal-body">

                    <form action="/create" method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="email">Image:<small style="color:red"> (Required!)</small></label>
                            <input type="file" name="product_image" class="form-control"required>
                        </div>

                        <div class="form-group">

                          <label for="email">Product Name:</label>

                          <input type="text" class="form-control" name="name" placeholder="Enter Product Name" id="email">

                        </div>
                        <div class="form-group">

                            <label for="email">Product Desc:</label>
  
                            <input type="text" class="form-control" name="desc" placeholder="Enter Product desc" id="email">
  
                        </div>

                        <div class="form-group">

                            <label for="email">Product Seller:</label>
  
                            <input type="text" class="form-control" name="seller" placeholder="Enter Product Seller" id="email">
  
                        </div>



                        

                        <button type="submit" class="btn btn-primary">Submit</button>

                      </form>

                </div>

                

                

              </div>

            </div>

          </div>
    </body>
</html><?php /**PATH D:\LaravelTutorial\Crud\resources\views/index.blade.php ENDPATH**/ ?>