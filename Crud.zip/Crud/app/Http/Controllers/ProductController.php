<?php

namespace App\Http\Controllers;
use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    //index function

    public function index(){
        //pull all data from table
        $product_data=Product::all();
        //return the view
        return view('index',compact('product_data'));
    }

    public function create(Request $request){
       
        //upload an image
        $request->validate([
            'product_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        
        //rename file name
        $imageName = time().'.'.$request->product_image->extension();  
        
        //move file in dir
        $request->product_image->move(public_path('images'),$imageName);
        
        //update table record
        Product::create( $request->only(['name','desc','seller']) + ['pic' => $imageName]);

       //return to page
        return redirect('index')->with('image',$imageName);
       
    }

    public function edit($id){

        //select record by id
        $product_data=Product::find($id);

        return view('edit',compact('product_data'));

    }


    public function update(Request $request,$id){
       
        //select record by id
        $product_data=Product::find($id);

        //upload an image
        $request->validate([
            'product_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        
        //rename file name
        $imageName = time().'.'.$request->product_image->extension();  
        
        //move file in dir
        $request->product_image->move(public_path('images'),$imageName);
      
        //update table record
        $product_data->update( $request->only(['name','desc','seller']) + ['pic' => $imageName]);

       //return to page
        return redirect('index')->with('image',$imageName);
       
    }

    public function delete($id){
        $product_data = Product::find($id);
        $product_data->delete();
        return redirect('index');

    }
}
