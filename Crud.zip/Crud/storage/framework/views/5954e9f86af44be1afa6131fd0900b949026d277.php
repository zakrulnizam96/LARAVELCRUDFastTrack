<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>   
</head>

<body>
    
<div class="modal-body">

<form action="/update/<?php echo e($product_data->id); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <img style="width:30%" src="/images/<?php echo e($product_data->pic); ?>" alt="prod img"><br>
            <label for="email">Image:<small style="color:red"> (Required!)</small></label>
            <input type="file" name="product_image" class="form-control"required>
        </div>

        <div class="form-group">

          <label for="email">Product Name:</label>

        <input type="text" class="form-control" value="<?php echo e($product_data->name); ?>" name="name" placeholder="Enter Product Name" id="email">

        </div>
        <div class="form-group">

            <label for="email">Product Desc:</label>

            <input type="text" class="form-control" value="<?php echo e($product_data->desc); ?>" name="desc" placeholder="Enter Product desc" id="email">

        </div>

        <div class="form-group">

            <label for="email">Product Seller:</label>

            <input type="text" class="form-control" value="<?php echo e($product_data->seller); ?>" name="seller" placeholder="Enter Product Seller" id="email">

        </div>



        

        <button type="submit" class="btn btn-primary">Submit</button>

      </form>

</div>
</body>
</html><?php /**PATH D:\LaravelTutorial\Crud\resources\views/edit.blade.php ENDPATH**/ ?>