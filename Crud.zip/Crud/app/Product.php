<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //make laravel know that this model refer to product table
    protected $table="product_tbl";

    //declare the col that can be insert the data
    protected $fillable=['name','desc','seller','pic'];

}
